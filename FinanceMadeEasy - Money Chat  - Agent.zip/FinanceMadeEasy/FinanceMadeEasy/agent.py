"""Financial coordinator: provide reasonable investment strategies"""

from google.adk.agents import LlmAgent
from google.adk.tools.agent_tool import AgentTool
import os
from .prompt import FINANCIAL_COORDINATOR_PROMPT
from .sub_agents.data_analyst import data_analyst_agent
from .sub_agents.finance_calculator import finance_calculator_agent  # Assuming this exists
from .sub_agents.risk_analyst import risk_analyst_agent
from .sub_agents.trading_analyst import trading_analyst_agent # Add if defined
from .sub_agents.fimoney_mcp import fi_money_mcp_agent

MODEL = "gemini-2.5-pro"  # Upgraded from flash for better reasoning in orchestration
if not os.getenv("GOOGLE_API_KEY"):
    raise ValueError("Please set the GOOGLE_API_KEY environment variable")

financial_coordinator = LlmAgent(
    name="financial_coordinator",
    model=MODEL,
    description=(
        "Guide users through a structured process to receive financial advice by orchestrating expert sub-agents. "
        "Analyze market tickers, develop trading strategies, define execution plans, evaluate risks, and fetch data from Fi Money MCP."
    ),
    instruction=FINANCIAL_COORDINATOR_PROMPT,
    output_key="financial_coordinator_output",
    tools=[
        AgentTool(agent=data_analyst_agent),
        AgentTool(agent=finance_calculator_agent),
        AgentTool(agent=risk_analyst_agent),
        AgentTool(agent=trading_analyst_agent), 
        AgentTool(agent=fi_money_mcp_agent),
    ],
)
root_agent = financial_coordinator