from google.adk import Agent
from .tools import (
    calculate_loan_affordability_tool,
    calculate_emergency_fund_adequacy_tool,
    calculate_investment_portfolio_allocation_tool,
    calculate_retirement_corpus_needed_tool,
    calculate_tax_optimization_tool
)
from . import prompt

MODEL = "gemini-2.5-pro"

finance_calculator_agent = Agent(
    model=MODEL,
    name="finance_calculator_agent",
    instruction=prompt.FINANCE_CALCULATOR_PROMPT,
    output_key="finance_calculator_output",
    tools=[
        calculate_loan_affordability_tool,
        calculate_emergency_fund_adequacy_tool,
        calculate_investment_portfolio_allocation_tool,
        calculate_retirement_corpus_needed_tool,
        calculate_tax_optimization_tool
    ]
)