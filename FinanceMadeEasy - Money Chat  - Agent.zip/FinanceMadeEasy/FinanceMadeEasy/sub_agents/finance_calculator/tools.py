import math
from typing import Dict, Any, Optional
from dataclasses import dataclass
from google.adk.tools import FunctionTool

@dataclass
class LoanAffordabilityResult:
    max_loan_amount: float
    recommended_loan_amount: float
    monthly_emi: float
    debt_to_income_ratio: float
    risk_assessment: str

class FinanceCalculatorTools:
    """Financial calculation tools for the finance calculator agent"""
    
    @staticmethod
    def calculate_loan_affordability(
        net_worth: float,
        monthly_income: float,
        existing_emis: float,
        credit_score: int,
        interest_rate: float = 8.5,
        tenure_years: int = 20
    ) -> Dict[str, Any]:
        """
        Calculate loan affordability based on financial profile
        
        Args:
            net_worth: Total net worth from MCP data
            monthly_income: Monthly income (derived from bank transactions)
            existing_emis: Current EMI obligations
            credit_score: Credit score from credit report
            interest_rate: Loan interest rate (default 8.5%)
            tenure_years: Loan tenure in years (default 20)
        """
        # Calculate DTI (Debt-to-Income) ratio
        current_dti = (existing_emis / monthly_income) * 100 if monthly_income > 0 else 100
        
        # Credit score adjustments
        credit_multiplier = 1.0
        if credit_score >= 750:
            credit_multiplier = 1.2
        elif credit_score >= 700:
            credit_multiplier = 1.0
        elif credit_score >= 650:
            credit_multiplier = 0.8
        else:
            credit_multiplier = 0.6
        
        # Calculate maximum affordable EMI (40% of income minus existing EMIs)
        max_affordable_emi = (monthly_income * 0.4) - existing_emis
        max_affordable_emi = max(0, max_affordable_emi) * credit_multiplier
        
        # Calculate loan amount using EMI formula
        monthly_rate = interest_rate / (12 * 100)
        num_payments = tenure_years * 12
        
        if monthly_rate > 0:
            max_loan_amount = max_affordable_emi * (
                (1 - (1 + monthly_rate) ** -num_payments) / monthly_rate
            )
        else:
            max_loan_amount = max_affordable_emi * num_payments
        
        # Consider net worth (20% of net worth as additional cushion)
        net_worth_factor = net_worth * 0.2
        max_loan_amount = min(max_loan_amount, net_worth_factor * 3)
        
        # Recommended loan amount (80% of max for safety)
        recommended_loan_amount = max_loan_amount * 0.8
        
        # Risk assessment
        final_dti = ((existing_emis + max_affordable_emi) / monthly_income) * 100
        if final_dti <= 30:
            risk_assessment = "Low Risk"
        elif final_dti <= 40:
            risk_assessment = "Moderate Risk"
        else:
            risk_assessment = "High Risk"
        
        return {
            "max_loan_amount": round(max_loan_amount, 2),
            "recommended_loan_amount": round(recommended_loan_amount, 2),
            "monthly_emi": round(max_affordable_emi, 2),
            "debt_to_income_ratio": round(final_dti, 2),
            "risk_assessment": risk_assessment
        }
    
    @staticmethod
    def calculate_emergency_fund_adequacy(
        monthly_expenses: float,
        liquid_savings: float,
        dependents: Optional[int] = None
    ) -> Dict[str, Any]:
        """Calculate if emergency fund is adequate"""
        if dependents is None:
            dependents = 0
        
        # Recommended emergency fund (3-6 months of expenses)
        base_months = 3 if dependents == 0 else 6
        recommended_fund = monthly_expenses * base_months
        
        current_coverage_months = liquid_savings / monthly_expenses if monthly_expenses > 0 else 0
        shortfall = max(0, recommended_fund - liquid_savings)
        
        adequacy_status = "Adequate" if current_coverage_months >= base_months else "Inadequate"
        
        return {
            "current_fund": liquid_savings,
            "recommended_fund": recommended_fund,
            "coverage_months": round(current_coverage_months, 1),
            "recommended_months": base_months,
            "shortfall": shortfall,
            "adequacy_status": adequacy_status
        }
    
    @staticmethod
    def calculate_investment_portfolio_allocation(
        age: int,
        risk_tolerance: str,
        current_equity: float,
        current_debt: float,
        current_gold: float
    ) -> Dict[str, Any]:
        """Calculate optimal portfolio allocation based on age and risk tolerance"""
        # Age-based equity allocation (100 - age rule with adjustments)
        base_equity_percent = max(20, 100 - age)
        
        # Risk tolerance adjustments
        risk_adjustments = {
            "conservative": -20,
            "moderate": 0,
            "aggressive": +20
        }
        
        equity_percent = base_equity_percent + risk_adjustments.get(risk_tolerance.lower(), 0)
        equity_percent = max(20, min(80, equity_percent))  # Cap between 20-80%
        
        # Recommended allocation
        debt_percent = max(20, 100 - equity_percent - 10)  # Reserve 10% for gold/others
        gold_percent = 10
        
        total_portfolio = current_equity + current_debt + current_gold
        
        if total_portfolio > 0:
            current_allocation = {
                "equity": round((current_equity / total_portfolio) * 100, 1),
                "debt": round((current_debt / total_portfolio) * 100, 1),
                "gold": round((current_gold / total_portfolio) * 100, 1)
            }
        else:
            current_allocation = {"equity": 0, "debt": 0, "gold": 0}
        
        recommended_allocation = {
            "equity": equity_percent,
            "debt": debt_percent,
            "gold": gold_percent
        }
        
        # Calculate rebalancing needed
        rebalancing_needed = {}
        if total_portfolio > 0:
            rebalancing_needed = {
                "equity": round((recommended_allocation["equity"] - current_allocation["equity"]), 1),
                "debt": round((recommended_allocation["debt"] - current_allocation["debt"]), 1),
                "gold": round((recommended_allocation["gold"] - current_allocation["gold"]), 1)
            }
        
        return {
            "current_allocation": current_allocation,
            "recommended_allocation": recommended_allocation,
            "rebalancing_needed": rebalancing_needed,
            "total_portfolio_value": total_portfolio
        }
    
    @staticmethod
    def calculate_retirement_corpus_needed(
        current_age: int,
        retirement_age: Optional[int] = None,
        monthly_expenses: Optional[float] = None,
        inflation_rate: Optional[float] = None,
        expected_return: Optional[float] = None
    ) -> Dict[str, Any]:
        """Calculate retirement corpus needed"""
        # Set defaults using None checking
        if retirement_age is None:
            retirement_age = 60
        if monthly_expenses is None:
            monthly_expenses = 50000.0
        if inflation_rate is None:
            inflation_rate = 6.0
        if expected_return is None:
            expected_return = 12.0
        
        years_to_retirement = retirement_age - current_age
        years_in_retirement = 25  # Assuming 25 years post retirement
        
        # Future value of current expenses at retirement
        future_monthly_expenses = monthly_expenses * ((1 + inflation_rate/100) ** years_to_retirement)
        future_annual_expenses = future_monthly_expenses * 12
        
        # Corpus needed at retirement (considering inflation during retirement)
        real_return_rate = (expected_return - inflation_rate) / 100
        if real_return_rate > 0:
            corpus_needed = future_annual_expenses * (1 - (1 + real_return_rate) ** -years_in_retirement) / real_return_rate
        else:
            corpus_needed = future_annual_expenses * years_in_retirement
        
        # Monthly SIP needed to achieve this corpus
        monthly_return_rate = expected_return / (12 * 100)
        months_to_retirement = years_to_retirement * 12
        
        if monthly_return_rate > 0 and months_to_retirement > 0:
            sip_needed = corpus_needed * monthly_return_rate / ((1 + monthly_return_rate) ** months_to_retirement - 1)
        else:
            sip_needed = corpus_needed / months_to_retirement if months_to_retirement > 0 else 0
        
        return {
            "years_to_retirement": years_to_retirement,
            "corpus_needed": round(corpus_needed, 2),
            "future_monthly_expenses": round(future_monthly_expenses, 2),
            "monthly_sip_needed": round(sip_needed, 2),
            "assumptions": {
                "inflation_rate": inflation_rate,
                "expected_return": expected_return,
                "retirement_years": years_in_retirement
            }
        }
    
    @staticmethod
    def calculate_tax_optimization(
        annual_income: float,
        current_80c_investments: Optional[float] = None,
        current_nps_contribution: Optional[float] = None,
        home_loan_interest: Optional[float] = None,
        home_loan_principal: Optional[float] = None
    ) -> Dict[str, Any]:
        """Calculate tax optimization suggestions"""
        # Set defaults using None checking
        if current_80c_investments is None:
            current_80c_investments = 0.0
        if current_nps_contribution is None:
            current_nps_contribution = 0.0
        if home_loan_interest is None:
            home_loan_interest = 0.0
        if home_loan_principal is None:
            home_loan_principal = 0.0
        
        # Old regime calculation with deductions
        old_regime_taxable = annual_income
        
        # 80C deductions (max 1.5L)
        deduction_80c = min(150000, current_80c_investments)
        old_regime_taxable -= deduction_80c
        
        # NPS additional deduction (max 50K)
        deduction_nps = min(50000, current_nps_contribution)
        old_regime_taxable -= deduction_nps
        
        # Home loan interest (max 2L)
        deduction_home_interest = min(200000, home_loan_interest)
        old_regime_taxable -= deduction_home_interest
        
        # Calculate taxes for both regimes
        def calculate_tax_old_regime(taxable_income):
            tax = 0
            if taxable_income > 250000:
                tax += min(taxable_income - 250000, 250000) * 0.05
            if taxable_income > 500000:
                tax += min(taxable_income - 500000, 500000) * 0.20
            if taxable_income > 1000000:
                tax += (taxable_income - 1000000) * 0.30
            return tax
        
        def calculate_tax_new_regime(taxable_income):
            tax = 0
            if taxable_income > 300000:
                tax += min(taxable_income - 300000, 300000) * 0.05
            if taxable_income > 600000:
                tax += min(taxable_income - 600000, 300000) * 0.10
            if taxable_income > 900000:
                tax += min(taxable_income - 900000, 300000) * 0.15
            if taxable_income > 1200000:
                tax += min(taxable_income - 1200000, 300000) * 0.20
            if taxable_income > 1500000:
                tax += (taxable_income - 1500000) * 0.30
            return tax
        
        old_regime_tax = calculate_tax_old_regime(old_regime_taxable)
        new_regime_tax = calculate_tax_new_regime(annual_income)
        
        # Add cess (4% of tax)
        old_regime_total = old_regime_tax * 1.04
        new_regime_total = new_regime_tax * 1.04
        
        savings_opportunity = max(0, 150000 - current_80c_investments)
        nps_opportunity = max(0, 50000 - current_nps_contribution)
        
        recommended_regime = "Old Regime" if old_regime_total < new_regime_total else "New Regime"
        tax_savings = abs(old_regime_total - new_regime_total)
        
        return {
            "old_regime_tax": round(old_regime_total, 2),
            "new_regime_tax": round(new_regime_total, 2),
            "recommended_regime": recommended_regime,
            "potential_savings": round(tax_savings, 2),
            "80c_savings_opportunity": savings_opportunity,
            "nps_savings_opportunity": nps_opportunity,
            "total_deductions_used": deduction_80c + deduction_nps + deduction_home_interest
        }

# Create FunctionTool instances
calculate_loan_affordability_tool = FunctionTool(func=FinanceCalculatorTools.calculate_loan_affordability)
calculate_emergency_fund_adequacy_tool = FunctionTool(func=FinanceCalculatorTools.calculate_emergency_fund_adequacy)
calculate_investment_portfolio_allocation_tool = FunctionTool(func=FinanceCalculatorTools.calculate_investment_portfolio_allocation)
calculate_retirement_corpus_needed_tool = FunctionTool(func=FinanceCalculatorTools.calculate_retirement_corpus_needed)
calculate_tax_optimization_tool = FunctionTool(func=FinanceCalculatorTools.calculate_tax_optimization)