"""FiMoney MCP Client agent for financial data operations"""

from google.adk import Agent
from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool
from google.adk.tools.agent_tool import AgentTool
from ..data_analyst import data_analyst_agent
from ..finance_calculator import finance_calculator_agent 
from . import prompt
import json
from typing import Dict, Any, Optional, List
from .mcp_client import get_mcp_client

MODEL = "gemini-2.5-pro"

# MCP Client tools based on actual Fi Money MCP server tools
class FiMoneyMCPTools:
    @staticmethod
    def fetch_net_worth() -> Dict[str, Any]:
        """Calculate comprehensive net worth using ONLY actual data from accounts users connected on Fi Money"""
        client = get_mcp_client()
        return client.fetch_net_worth()
    
    @staticmethod
    def fetch_credit_report() -> Dict[str, Any]:
        """Retrieve comprehensive credit report including scores and payment history"""
        client = get_mcp_client()
        return client.fetch_credit_report()
    
    @staticmethod
    def fetch_epf_details() -> Dict[str, Any]:
        """Retrieve detailed EPF account information"""
        client = get_mcp_client()
        return client.fetch_epf_details()
    
    @staticmethod
    def fetch_mf_transactions() -> Dict[str, Any]:
        """Retrieve detailed mutual fund transaction history"""
        client = get_mcp_client()
        return client.fetch_mf_transactions()
    
    @staticmethod
    def fetch_bank_transactions() -> Dict[str, Any]:
        """Retrieve detailed bank transactions for connected accounts"""
        client = get_mcp_client()
        return client.fetch_bank_transactions()
    
    @staticmethod
    def fetch_stock_transactions() -> Dict[str, Any]:
        """Retrieve detailed Indian stock transactions"""
        client = get_mcp_client()
        return client.fetch_stock_transactions()

# Create FunctionTool instances with only the func parameter
fetch_net_worth_tool = FunctionTool(func=FiMoneyMCPTools.fetch_net_worth)
fetch_credit_report_tool = FunctionTool(func=FiMoneyMCPTools.fetch_credit_report)
fetch_epf_details_tool = FunctionTool(func=FiMoneyMCPTools.fetch_epf_details)
fetch_mf_transactions_tool = FunctionTool(func=FiMoneyMCPTools.fetch_mf_transactions)
fetch_bank_transactions_tool = FunctionTool(func=FiMoneyMCPTools.fetch_bank_transactions)
fetch_stock_transactions_tool = FunctionTool(func=FiMoneyMCPTools.fetch_stock_transactions)

# Create the agent with FunctionTool instances
fi_money_mcp_agent = Agent(
    model=MODEL,
    name="fi_money_mcp_agent",
    instruction=prompt.FI_MONEY_MCP_PROMPT,
    output_key="fi_money_mcp_output",
    tools=[
        AgentTool(agent=data_analyst_agent),  # To analyze fetched MCP data
        AgentTool(agent=finance_calculator_agent),
        fetch_net_worth_tool,
        fetch_credit_report_tool,
        fetch_epf_details_tool,
        fetch_mf_transactions_tool,
        fetch_bank_transactions_tool,
        fetch_stock_transactions_tool
    ]
)