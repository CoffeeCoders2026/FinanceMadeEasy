"""FiMoney MCP Client subagent package"""

from .agent import fi_money_mcp_agent
__all__ = ["fi_money_mcp_agent"]