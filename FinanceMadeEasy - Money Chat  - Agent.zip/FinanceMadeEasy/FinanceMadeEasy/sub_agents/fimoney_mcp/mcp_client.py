"""MCP Client for Fi Money server communication"""

import requests
import json
import logging
import os
from typing import Dict, Any, Optional
from dataclasses import dataclass

@dataclass
class MCPConfig:
    """Configuration for MCP client"""
    server_url: str = "http://localhost:8080/mcp/stream"
    session_id: str = "mcp-session-594e48ea-fea1-40ef-8c52-7552dd9272af"  # Update with your session ID
    timeout: int = 30
    max_retries: int = 0

class FiMoneyMCPClient:
    """Client for communicating with Fi Money MCP server"""
    
    def __init__(self, config: MCPConfig = None, session_id: str = None):
        self.config = config or MCPConfig()
        self.logger = logging.getLogger(__name__)
        
        # Override with environment variables if available
        if os.getenv("MCP_SERVER_URL"):
            self.config.server_url = os.getenv("MCP_SERVER_URL")
        if os.getenv("MCP_SESSION_ID"):
            self.config.session_id = os.getenv("MCP_SESSION_ID")
        
        # Override with provided session_id if available
        if session_id:
            self.config.session_id = session_id
    
    def _send_request(self, method: str, arguments: Dict[str, Any] = None) -> Dict[str, Any]:
        """Send a request to the MCP server"""
        headers = {
            'Mcp-Session-Id': self.config.session_id,
            'Content-Type': 'application/json'
        }
        
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": method,
                "arguments": arguments or {}
            }
        }
        
        try:
            self.logger.info(f"Sending MCP request: {method}")
            response = requests.post(
                self.config.server_url,
                headers=headers,
                json=payload,
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            self.logger.info(f"MCP response received for {method}")
            
            if "error" in result:
                self.logger.error(f"MCP error for {method}: {result['error']}")
                return {"status": "error", "message": result["error"]}
                
            return {"status": "success", "data": result.get("result", {})}
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"MCP request failed for {method}: {e}")
            return {"status": "error", "message": f"Request failed: {str(e)}"}
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error for {method}: {e}")
            return {"status": "error", "message": f"Invalid JSON response: {str(e)}"}
        except Exception as e:
            self.logger.error(f"Unexpected error for {method}: {e}")
            return {"status": "error", "message": f"Unexpected error: {str(e)}"}
    
    def fetch_net_worth(self) -> Dict[str, Any]:
        """Fetch net worth data from MCP server"""
        return self._send_request("fetch_net_worth")
    
    def fetch_credit_report(self) -> Dict[str, Any]:
        """Fetch credit report data from MCP server"""
        return self._send_request("fetch_credit_report")
    
    def fetch_epf_details(self) -> Dict[str, Any]:
        """Fetch EPF details from MCP server"""
        return self._send_request("fetch_epf_details")
    
    def fetch_mf_transactions(self) -> Dict[str, Any]:
        """Fetch mutual fund transactions from MCP server"""
        return self._send_request("fetch_mf_transactions")
    
    def fetch_bank_transactions(self) -> Dict[str, Any]:
        """Fetch bank transactions from MCP server"""
        return self._send_request("fetch_bank_transactions")
    
    def fetch_stock_transactions(self) -> Dict[str, Any]:
        """Fetch stock transactions from MCP server"""
        return self._send_request("fetch_stock_transactions")

# Global client instances - keyed by session_id
_mcp_clients = {}

def get_mcp_client(session_id: str = None) -> FiMoneyMCPClient:
    """Get or create MCP client instance for a specific session"""
    global _mcp_clients
    
    # Use default session if none provided
    if session_id is None:
        session_id = "mcp-session-594e48ea-fea1-40ef-8c52-7552dd9272af"  # Default session
    
    # Create new client if not exists for this session
    if session_id not in _mcp_clients:
        _mcp_clients[session_id] = FiMoneyMCPClient(session_id=session_id)
    
    return _mcp_clients[session_id]