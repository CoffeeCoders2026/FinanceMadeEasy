export interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface FinancialAsset {
  id: string;
  title: string;
  content: string;
  category: 'portfolio' | 'investment' | 'spending' | 'savings' | 'market' | 'general';
  timestamp: Date;
  exported: boolean;
}

export interface ExportedSuggestion {
  id: string;
  title: string;
  content: string;
  category: string;
  exportedAt: Date;
  originalMessageId: string;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
}