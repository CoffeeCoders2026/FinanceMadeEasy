import React, { useState, useEffect } from 'react';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import ChatInterface from './components/ChatInterface';
import FinancialAssets from './components/FinancialAssets';
import Navigation from './components/Navigation';
import { User } from './types';
import { apiService, setAuthToken, getAuthToken } from './services/api';
import AIDashboard from './components/AIDashboard';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentView, setCurrentView] = useState<'ai-analysis' |'dashboard' | 'chat' | 'assets' >('ai-analysis');

  // Check for existing session on app load
  useEffect(() => {
    const checkAuth = async () => {
      const token = getAuthToken();
      if (token) {
        try {
          const response = await apiService.getCurrentUser();
          setUser(response.user);
          setIsAuthenticated(true);
        } catch (error) {
          // Token is invalid, clear it
          setAuthToken(null);
        }
      }
      setIsLoading(false);
    };

    checkAuth();
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setCurrentView('dashboard');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LandingPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        user={user!}
        onLogout={handleLogout}
      />
      <main className="pt-16">
        {currentView === 'ai-analysis' && <AIDashboard />}
        {currentView === 'dashboard' && <Dashboard user={user!} />}
        {currentView === 'chat' && <ChatInterface />}
        {currentView === 'assets' && <FinancialAssets />}
      </main>
    </div>
  );
}

export default App;