import React, { useState, useEffect } from 'react';
import { FileText, Calendar, Tag, Trash2, Download, Search, Filter } from 'lucide-react';
import { storageService } from '../services/storageService';
import { ExportedSuggestion } from '../types';

const FinancialAssets: React.FC = () => {
  const [suggestions, setSuggestions] = useState<ExportedSuggestion[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date' | 'category'>('date');

  useEffect(() => {
    loadSuggestions();
  }, []);

  const loadSuggestions = () => {
    const loaded = storageService.getExportedSuggestions();
    setSuggestions(loaded);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this suggestion?')) {
      storageService.deleteExportedSuggestion(id);
      loadSuggestions();
    }
  };

  const handleExportAll = () => {
    const dataStr = JSON.stringify(suggestions, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `financial-assets-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      portfolio: 'bg-blue-100 text-blue-800',
      investment: 'bg-green-100 text-green-800',
      spending: 'bg-purple-100 text-purple-800',
      savings: 'bg-orange-100 text-orange-800',
      market: 'bg-red-100 text-red-800',
      general: 'bg-gray-100 text-gray-800',
    };
    return colors[category] || colors.general;
  };

  const filteredSuggestions = suggestions
    .filter(suggestion => {
      const matchesSearch = suggestion.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           suggestion.content.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || suggestion.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === 'date') {
        return new Date(b.exportedAt).getTime() - new Date(a.exportedAt).getTime();
      } else {
        return a.category.localeCompare(b.category);
      }
    });

  const categories = ['all', ...Array.from(new Set(suggestions.map(s => s.category)))];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 min-h-screen">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="animate-fade-in">
              <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                Financial Assets
              </h2>
              <p className="text-gray-600 text-lg">Your saved AI suggestions and financial insights</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleExportAll}
              disabled={suggestions.length === 0}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl hover:from-blue-600 hover:to-purple-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <Download className="w-4 h-4" />
              <span>Export All</span>
            </button>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search suggestions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 bg-white hover:shadow-md"
            />
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="border border-gray-300 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 bg-white hover:shadow-md"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'date' | 'category')}
              className="border border-gray-300 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 bg-white hover:shadow-md"
            >
              <option value="date">Sort by Date</option>
              <option value="category">Sort by Category</option>
            </select>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <div className="bg-gradient-to-br from-white to-blue-50 rounded-xl shadow-lg border border-blue-100 p-4 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 animate-slide-up">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg transform hover:rotate-12 transition-transform duration-300">
              <FileText className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">{suggestions.length}</div>
              <div className="text-sm text-gray-600">Total Suggestions</div>
            </div>
          </div>
        </div>
        <div className="bg-gradient-to-br from-white to-green-50 rounded-xl shadow-lg border border-green-100 p-4 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg transform hover:rotate-12 transition-transform duration-300">
              <Tag className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent">{categories.length - 1}</div>
              <div className="text-sm text-gray-600">Categories</div>
            </div>
          </div>
        </div>
        <div className="bg-gradient-to-br from-white to-purple-50 rounded-xl shadow-lg border border-purple-100 p-4 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 animate-slide-up" style={{ animationDelay: '0.2s' }}>
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center shadow-lg transform hover:rotate-12 transition-transform duration-300">
              <Calendar className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <div className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                {suggestions.length > 0 ? Math.ceil((Date.now() - new Date(suggestions[suggestions.length - 1].exportedAt).getTime()) / (1000 * 60 * 60 * 24)) : 0}
              </div>
              <div className="text-sm text-gray-600">Days Active</div>
            </div>
          </div>
        </div>
      </div>

      {/* Suggestions List */}
      {filteredSuggestions.length === 0 ? (
        <div className="bg-gradient-to-br from-white to-gray-50 rounded-xl shadow-lg border border-gray-200 p-12 text-center animate-fade-in">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            {suggestions.length === 0 ? 'No suggestions saved yet' : 'No suggestions match your filters'}
          </h3>
          <p className="text-gray-600">
            {suggestions.length === 0 
              ? 'Start chatting with the AI assistant and export valuable suggestions to build your financial knowledge base.'
              : 'Try adjusting your search terms or category filters to find what you\'re looking for.'
            }
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredSuggestions.map((suggestion) => (
            <div key={suggestion.id} className="bg-gradient-to-br from-white to-gray-50 rounded-xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 animate-slide-up">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{suggestion.title}</h3>
                    <span className={`px-2 py-1 text-xs rounded-full ${getCategoryColor(suggestion.category)}`}>
                      {suggestion.category.charAt(0).toUpperCase() + suggestion.category.slice(1)}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>{suggestion.exportedAt.toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span>{suggestion.exportedAt.toLocaleTimeString()}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(suggestion.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all duration-300 transform hover:scale-110"
                  title="Delete suggestion"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="prose prose-sm max-w-none">
                <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{suggestion.content}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FinancialAssets;