import React from 'react';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { apiService } from '../services/api';
import { useApi } from '../hooks/useApi';
import PortfolioChart from './PortfolioChart';

const PortfolioOverview: React.FC = () => {
  const { data, loading, error } = useApi(() => apiService.getPortfolio());

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/3 mb-6"></div>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex justify-between">
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/6"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="text-red-600 text-center">
          <p>Error loading portfolio data</p>
          <p className="text-sm text-gray-600 mt-1">{error}</p>
        </div>
      </div>
    );
  }

  if (!data) return null;

  const { portfolio: portfolioData, totalValue, totalChange } = data;

  return (
    <div className="bg-gradient-to-br from-white to-blue-50 rounded-xl shadow-lg border border-blue-100 p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Portfolio Overview
        </h3>
        <span className="text-2xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
          ${totalValue.toLocaleString()}
        </span>
      </div>
      
      <div className="flex items-center space-x-2 mb-6">
        <div className={`flex items-center space-x-1 text-sm px-3 py-1 rounded-full ${
          totalChange >= 0 
            ? 'bg-green-100 text-green-700 border border-green-200' 
            : 'bg-red-100 text-red-700 border border-red-200'
        } animate-bounce`}>
          {totalChange >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
          <span>{totalChange >= 0 ? '+' : ''}${totalChange.toFixed(2)} today</span>
        </div>
      </div>
      
      <div className="space-y-4">
        {portfolioData.map((stock) => (
          <div key={stock.symbol} className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-gray-50 to-blue-50 hover:from-blue-50 hover:to-purple-50 transition-all duration-300 transform hover:scale-102 border border-gray-100 hover:border-blue-200 hover:shadow-md">
            <div>
              <div className="font-bold text-gray-900 text-lg">{stock.symbol}</div>
              <div className="text-sm text-gray-600">{stock.name}</div>
            </div>
            <div className="text-right">
              <div className="font-bold text-gray-900 text-lg">${stock.value.toLocaleString()}</div>
              <div className={`text-sm flex items-center space-x-1 px-2 py-1 rounded-full ${
                stock.change >= 0 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-red-100 text-red-700'
              } animate-pulse`}>
                {stock.change >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                <span>{stock.change >= 0 ? '+' : ''}{stock.changePercent}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <PortfolioChart portfolioData={portfolioData} />
    </div>
  );
};

export default PortfolioOverview;