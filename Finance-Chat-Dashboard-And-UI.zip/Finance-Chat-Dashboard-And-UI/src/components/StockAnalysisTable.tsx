import React, { useState, useEffect } from "react";
import { Tooltip, Modal } from "antd";
import { InfoCircleOutlined } from "@ant-design/icons";

const StockAnalysisTable = () => {
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState({ visible: false, stock: null });
  const [stockData, setStockData] = useState([]);

  useEffect(() => {
    const fetchStockData = async () => {
      try {
        const response = await fetch("http://localhost:3001/api/stock-analysis", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({}),
        });

        const result = await response.json();
        console.log("Stock Analysis Result:", result);
        if (!result.success) {
          throw new Error(result.error || "Failed to fetch stock analysis");
        }

        // Transform API response to match the component's expected format
        const transformedData = result.data.map((stock) => ({
            name: stock.symbol,
            analysis: stock.reason,
            details: {
                "PE Ratio": stock.peRatio || "N/A",
                "Profit Margin": stock.profitMargin || "N/A",
                "50 Day Moving Avg": stock.fiftyDayMovingAverage || "N/A",
                "Beta": stock.beta || "N/A",
                "52 Week High": stock.fiftyTwoWeekHigh || "N/A",
                "52 Week Low": stock.fiftyTwoWeekLow || "N/A",
            },
            }));

        setStockData(transformedData);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching stock data:", error);
        setLoading(false);
      }
    };

    fetchStockData();
  }, []);

  return (
    <div className="w-full mt-8">
      {loading ? (
        <div className="w-full min-h-[220px] flex flex-col items-center justify-center bg-gray-50 rounded-lg shadow-sm">
          <span className="text-5xl mb-4">🤖</span>
          <span className="text-lg text-gray-500">
            AI is analyzing stock data...
          </span>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Stock
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    AI Analysis
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-100">
                {stockData.map((stock) => (
                  <tr key={stock.name} className="hover:bg-blue-50 transition-colors">
                    <td className="px-4 py-2 whitespace-nowrap font-bold text-gray-900 flex items-center gap-2">
                      <span>{stock.name}</span>
                      <Tooltip title="Show details">
                        <InfoCircleOutlined
                          style={{
                            color: "#1890ff",
                            fontSize: 18,
                            cursor: "pointer",
                            verticalAlign: "middle",
                          }}
                          onClick={() =>
                            setModal({ visible: true, stock: stock })
                          }
                        />
                      </Tooltip>
                    </td>
                    <td className="px-4 py-2">{stock.analysis}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal
        open={modal.visible}
        onCancel={() => setModal({ visible: false, stock: null })}
        footer={null}
        centered
        width={440}
        bodyStyle={{
          padding: 32,
          borderRadius: 16,
          background: "#f6f8fa",
        }}
      >
        {modal.stock && (
          <div>
            <h2 style={{ marginBottom: 24, fontWeight: 700 }}>
              {modal.stock.name} - Details
            </h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Metric
                    </th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Value
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {Object.entries(modal.stock.details).map(([k, v]) => (
                    <tr key={k} className="hover:bg-blue-50 transition-colors">
                      <td className="px-4 py-2 whitespace-nowrap font-medium text-gray-900">
                        {k}
                      </td>
                      <td className="px-4 py-2">{v}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default StockAnalysisTable;