import React from 'react';
import { BarChart3, MessageSquare, TrendingUp, FileText, LogOut, User } from 'lucide-react';
import { apiService, setAuthToken } from '../services/api';
import { User as UserType } from '../types';

interface NavigationProps {
  currentView: 'ai-analysis' | 'dashboard' | 'chat' | 'assets' ;
  setCurrentView: (view: 'ai-analysis' | 'dashboard' | 'chat' | 'assets' ) => void;
  user: UserType;
  onLogout: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, setCurrentView, user, onLogout }) => {
  const handleLogout = async () => {
    try {
      await apiService.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setAuthToken(null);
      onLogout();
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 shadow-lg z-10 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <div className="relative">
              <TrendingUp className="w-8 h-8 text-white animate-pulse" />
              <div className="absolute inset-0 w-8 h-8 bg-white opacity-20 rounded-full animate-ping"></div>
            </div>
            <h1 className="text-xl font-bold text-white tracking-wide">MoneyChat</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
            <button
              onClick={() => setCurrentView('ai-analysis')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 transform hover:scale-105 ${
                currentView === 'ai-analysis'
                  ? 'bg-white bg-opacity-20 text-white shadow-lg backdrop-blur-sm'
                  : 'text-white text-opacity-80 hover:text-white hover:bg-white hover:bg-opacity-10'
              }`}
            >
              <TrendingUp className="w-4 h-4 inline mr-2" />
              Portfolio
            </button>
            <button
              onClick={() => setCurrentView('dashboard')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 transform hover:scale-105 ${
                currentView === 'dashboard'
                  ? 'bg-white bg-opacity-20 text-white shadow-lg backdrop-blur-sm'
                  : 'text-white text-opacity-80 hover:text-white hover:bg-white hover:bg-opacity-10'
              }`}
            >
              <BarChart3 className="w-4 h-4 inline mr-2" />
              Dashboard
            </button>
            <button
              onClick={() => setCurrentView('chat')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 transform hover:scale-105 ${
                currentView === 'chat'
                  ? 'bg-white bg-opacity-20 text-white shadow-lg backdrop-blur-sm'
                  : 'text-white text-opacity-80 hover:text-white hover:bg-white hover:bg-opacity-10'
              }`}
            >
              <MessageSquare className="w-4 h-4 inline mr-2" />
              AI Assistant
            </button>
            <button
              onClick={() => setCurrentView('assets')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 transform hover:scale-105 ${
                currentView === 'assets'
                  ? 'bg-white bg-opacity-20 text-white shadow-lg backdrop-blur-sm'
                  : 'text-white text-opacity-80 hover:text-white hover:bg-white hover:bg-opacity-10'
              }`}
            >
              <FileText className="w-4 h-4 inline mr-2" />
              Financial Assets
            </button>
            
            </div>
            
            <div className="flex items-center space-x-3 border-l border-white/20 pl-4">
              <div className="flex items-center space-x-2 text-white">
                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium">{user.firstName} {user.lastName}</span>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 px-3 py-2 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-300 transform hover:scale-105"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;