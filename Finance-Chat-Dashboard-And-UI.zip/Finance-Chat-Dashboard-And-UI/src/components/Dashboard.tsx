import React from 'react';
import PortfolioOverview from './PortfolioOverview';
import SpendingAnalysis from './SpendingAnalysis';
import SavingsGoals from './SavingsGoals';
import StockRecommendations from './StockRecommendations';
import RecentTransactions from './RecentTransactions';
import MarketOverview from './MarketOverview';
import StockStatsTable from './StockStatsTable';
import { User } from '../types';
import StockAnalysisTable from './StockAnalysisTable';

interface DashboardProps {
  user: User;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 min-h-screen">
      <div className="mb-8">
        <div className="animate-fade-in">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            Welcome back, {user.firstName}
          </h2>
          <p className="text-gray-600 text-lg">Here's your financial overview for today</p>
        </div>
      </div>
      
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8 animate-slide-up" style={{ animationDelay: '0.2s' }}>
        <SpendingAnalysis />
        <SavingsGoals />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-slide-up" style={{ animationDelay: '0.4s' }}>
        <StockRecommendations />
        <RecentTransactions />
      </div>
      
      
    </div>
  );
};

export default Dashboard;