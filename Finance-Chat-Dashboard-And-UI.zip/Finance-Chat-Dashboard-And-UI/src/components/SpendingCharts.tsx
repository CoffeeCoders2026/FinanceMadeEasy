import React, { useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import { BarChart3, PieChart } from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface SpendingChartsProps {
  spendingData: Array<{
    category: string;
    amount: number;
    icon: string;
    color: string;
  }>;
  total: number;
}

const SpendingCharts: React.FC<SpendingChartsProps> = ({ spendingData, total }) => {
  const [chartType, setChartType] = useState<'pie' | 'bar'>('pie');

  // Convert Tailwind colors to chart-friendly colors
  const getChartColor = (tailwindColor: string) => {
    const colorMap: { [key: string]: string } = {
      'bg-blue-500': 'rgba(59, 130, 246, 0.8)',
      'bg-green-500': 'rgba(16, 185, 129, 0.8)',
      'bg-purple-500': 'rgba(139, 92, 246, 0.8)',
      'bg-orange-500': 'rgba(249, 115, 22, 0.8)',
      'bg-red-500': 'rgba(239, 68, 68, 0.8)',
      'bg-yellow-500': 'rgba(245, 158, 11, 0.8)',
    };
    return colorMap[tailwindColor] || 'rgba(107, 114, 128, 0.8)';
  };

  const getBorderColor = (tailwindColor: string) => {
    return getChartColor(tailwindColor).replace('0.8', '1');
  };

  const pieData = {
    labels: spendingData.map(item => item.category),
    datasets: [
      {
        data: spendingData.map(item => item.amount),
        backgroundColor: spendingData.map(item => getChartColor(item.color)),
        borderColor: spendingData.map(item => getBorderColor(item.color)),
        borderWidth: 2,
        hoverOffset: 8,
      },
    ],
  };

  const barData = {
    labels: spendingData.map(item => item.category),
    datasets: [
      {
        label: 'Amount Spent',
        data: spendingData.map(item => item.amount),
        backgroundColor: spendingData.map(item => getChartColor(item.color)),
        borderColor: spendingData.map(item => getBorderColor(item.color)),
        borderWidth: 1,
        borderRadius: 6,
        borderSkipped: false,
      },
    ],
  };

  const pieOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right' as const,
        labels: {
          usePointStyle: true,
          padding: 20,
          font: {
            size: 12,
          },
          generateLabels: function(chart: any) {
            const data = chart.data;
            if (data.labels.length && data.datasets.length) {
              return data.labels.map((label: string, i: number) => {
                const amount = data.datasets[0].data[i];
                const percentage = ((amount / total) * 100).toFixed(1);
                return {
                  text: `${label} (${percentage}%)`,
                  fillStyle: data.datasets[0].backgroundColor[i],
                  strokeStyle: data.datasets[0].borderColor[i],
                  lineWidth: data.datasets[0].borderWidth,
                  pointStyle: 'circle',
                  hidden: false,
                  index: i,
                };
              });
            }
            return [];
          },
        },
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        borderWidth: 1,
        cornerRadius: 8,
        callbacks: {
          label: function(context: any) {
            const percentage = ((context.parsed / total) * 100).toFixed(1);
            return `${context.label}: $${context.parsed.toLocaleString()} (${percentage}%)`;
          },
        },
      },
    },
  };

  const barOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        borderWidth: 1,
        cornerRadius: 8,
        callbacks: {
          label: function(context: any) {
            const percentage = ((context.parsed.y / total) * 100).toFixed(1);
            return `Amount: $${context.parsed.y.toLocaleString()} (${percentage}%)`;
          },
        },
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          color: '#6B7280',
          font: {
            size: 11,
          },
        },
      },
      y: {
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          color: '#6B7280',
          font: {
            size: 11,
          },
          callback: function(value: any) {
            return '$' + value.toLocaleString();
          },
        },
      },
    },
  };

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-medium text-gray-900">Spending Breakdown</h4>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setChartType('pie')}
            className={`p-2 rounded-lg transition-colors duration-200 ${
              chartType === 'pie'
                ? 'bg-blue-100 text-blue-600'
                : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'
            }`}
            title="Pie Chart"
          >
            <PieChart className="w-4 h-4" />
          </button>
          <button
            onClick={() => setChartType('bar')}
            className={`p-2 rounded-lg transition-colors duration-200 ${
              chartType === 'bar'
                ? 'bg-blue-100 text-blue-600'
                : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'
            }`}
            title="Bar Chart"
          >
            <BarChart3 className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      <div className="h-64 w-full">
        {chartType === 'pie' ? (
          <Pie data={pieData} options={pieOptions} />
        ) : (
          <Bar data={barData} options={barOptions} />
        )}
      </div>
      
      <div className="mt-4 text-xs text-gray-500 text-center">
        {chartType === 'pie' 
          ? 'View your spending distribution across different categories'
          : 'Compare spending amounts across different categories'
        }
      </div>
      
      <div className="mt-4 grid grid-cols-2 gap-4 text-xs">
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="font-medium text-gray-900">Total Spent</div>
          <div className="text-lg font-semibold text-gray-900">${total.toLocaleString()}</div>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="font-medium text-gray-900">Largest Category</div>
          <div className="text-lg font-semibold text-gray-900">
            {spendingData.reduce((max, item) => item.amount > max.amount ? item : max).category}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SpendingCharts;