import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, TrendingUp, DollarSign, PieChart, Target, Download, Trash2, Mic } from 'lucide-react';
import { apiService } from '../services/api'; // Use the updated api.ts
import { storageService } from '../services/storageService';
import { Message, ExportedSuggestion } from '../types';

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: "Hello! I'm your personal finance AI assistant. I can help you with portfolio analysis, investment recommendations, spending insights, and savings strategies. What would you like to know?",
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [exportingId, setExportingId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    const fetchChatHistory = async () => {
      try {
        const response = await apiService.getChatHistory();
        if (response.chatHistory) {
          // Merge initial message with fetched history, ensuring no duplicates
          const historyMessages = response.chatHistory.map((msg: any) => ({
            id: msg.id,
            type: msg.type,
            content: msg.content,
            timestamp: new Date(msg.timestamp),
          }));
          setMessages((prev) => {
            const existingIds = new Set(prev.map((m) => m.id));
            const newMessages = historyMessages.filter((m: Message) => !existingIds.has(m.id));
            return [...prev, ...newMessages];
          });
        }
      } catch (error) {
        console.error("Failed to fetch chat history:", error);
      }
    };

    fetchChatHistory();
    scrollToBottom();
  }, []);

  // Initialize SpeechRecognition
  useEffect(() => {
    if ("SpeechRecognition" in window || "webkitSpeechRecognition" in window) {
      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = "en-US";

      recognitionRef.current.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map((result) => result[0].transcript)
          .join("");
        setInputValue(transcript);
      };

      recognitionRef.current.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        setIsRecording(false);
        const errorMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: "assistant",
          content:
            "Sorry, there was an error with voice input. Please try again or type your message.",
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, errorMessage]);
      };

      recognitionRef.current.onend = () => {
        setIsRecording(false);
      };
    }
  }, []);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await apiService.sendChatMessage(inputValue);
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response.response,
        timestamp: new Date(response.timestamp),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearChat = async () => {
    try {
      await apiService.clearChatHistory();
      setMessages([
        {
          id: '1',
          type: 'assistant',
          content: "Hello! I'm your personal finance AI assistant. I can help you with portfolio analysis, investment recommendations, spending insights, and savings strategies. What would you like to know?",
          timestamp: new Date()
        }
      ]);
    } catch (error) {
      console.error("Failed to clear chat history:", error);
    }
  };

  const quickActions = [
    { icon: TrendingUp, label: 'Portfolio Analysis', query: 'Analyze my current portfolio performance' },
    { icon: DollarSign, label: 'Investment Ideas', query: 'What are some good investment opportunities right now?' },
    { icon: PieChart, label: 'Spending Analysis', query: 'Break down my spending patterns this month' },
    { icon: Target, label: 'Savings Goals', query: 'Help me optimize my savings strategy' },
  ];


  const handleQuickAction = (query: string) => {
    setInputValue(query);
  };

  const handleExportSuggestion = async (message: Message) => {
    if (message.type !== 'assistant') return;
    
    setExportingId(message.id);
    
    try {
      // Determine category based on message content
      const content = message.content.toLowerCase();
      let category = 'general';
      
      if (content.includes('portfolio') || content.includes('stock')) {
        category = 'portfolio';
      } else if (content.includes('invest') || content.includes('buy') || content.includes('recommendation')) {
        category = 'investment';
      } else if (content.includes('spending') || content.includes('expense') || content.includes('budget')) {
        category = 'spending';
      } else if (content.includes('saving') || content.includes('goal')) {
        category = 'savings';
      } else if (content.includes('market') || content.includes('economy')) {
        category = 'market';
      }
      
      const exportedSuggestion: ExportedSuggestion = {
        id: Date.now().toString(),
        title: `AI Suggestion - ${category.charAt(0).toUpperCase() + category.slice(1)}`,
        content: message.content,
        category,
        exportedAt: new Date(),
        originalMessageId: message.id,
      };
      
      storageService.saveExportedSuggestion(exportedSuggestion);
      
      // Show success feedback (you could add a toast notification here)
    } catch (error) {
      console.error('Failed to export suggestion:', error);
    } finally {
      setExportingId(null);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleRecording = () => {
    if (!recognitionRef.current) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content:
          "Voice input is not supported in this browser. Please type your message.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsRecording(true);
      } catch (error) {
        console.error("Error starting voice recognition:", error);
        setIsRecording(false);
        const errorMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: "assistant",
          content:
            "Could not access microphone. Please check permissions and try again.",
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, errorMessage]);
      }
    }
  };

  const readMessageAloud = (messageId: string, content: string) => {
    if ("speechSynthesis" in window) {
      // Stop any ongoing speech
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(content);
      utterance.lang = "en-US";
      utterance.onstart = () => setSpeakingMessageId(messageId);
      utterance.onend = () => setSpeakingMessageId(null);
      utterance.onerror = () => {
        setSpeakingMessageId(null);
        const errorMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: "assistant",
          content:
            "Sorry, there was an error with text-to-speech. Please try again.",
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, errorMessage]);
      };
      window.speechSynthesis.speak(utterance);
    } else {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: "Text-to-speech is not supported in this browser.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 h-screen flex flex-col bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="mb-6">
        <div className="animate-fade-in">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            AI Financial Assistant
          </h2>
          <p className="text-gray-600 text-lg">Get personalized financial advice and insights</p>
        </div>
      </div>

      {messages.length === 1 && (
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-700 mb-3">Quick Actions</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <button
                  key={index}
                  onClick={() => handleQuickAction(action.query)}
                  className="flex items-center space-x-3 p-4 bg-gradient-to-r from-white to-blue-50 rounded-xl border border-blue-200 hover:border-blue-400 hover:shadow-lg transition-all duration-300 text-left transform hover:scale-105 hover:-translate-y-1"
                >
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg transform hover:rotate-12 transition-transform duration-300">
                    <Icon className="w-4 h-4 text-blue-600" />
                  </div>
                  <span className="text-sm font-semibold text-gray-900">{action.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div className="flex-1 bg-gradient-to-br from-white to-gray-50 rounded-xl shadow-lg border border-gray-200 flex flex-col animate-slide-up">
        <div className="flex justify-end p-4">
          <button
            onClick={handleClearChat}
            className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl hover:from-red-600 hover:to-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear Chat</span>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((message) => (
            <div 
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transform hover:scale-110 transition-transform duration-300 ${
                message.type === 'user' 
                  ? 'bg-gradient-to-r from-blue-500 to-purple-500' 
                  : 'bg-gradient-to-r from-gray-100 to-blue-100'
              }`}>
                {message.type === 'user' ? (
                  <User className="w-4 h-4 text-white" />
                ) : (
                  <Bot className="w-4 h-4 text-blue-600" />
                )}
              </div>
              <div className={`flex-1 max-w-2xl ${
                message.type === 'user' ? 'text-right' : ''
              }`}>
                <div className="relative group">
                  <div className={`inline-block p-4 rounded-2xl shadow-lg transform hover:scale-102 transition-all duration-300 ${
                    message.type === 'user'
                      ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white'
                      : 'bg-gradient-to-r from-gray-100 to-blue-50 text-gray-900 border border-gray-200'
                  }`}>
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  </div>
                  {message.type === 'assistant' && message.id !== '1' && (
                    <button
                      onClick={() => handleExportSuggestion(message)}
                      disabled={exportingId === message.id}
                      className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-full opacity-0 group-hover:opacity-100 hover:from-green-600 hover:to-blue-600 transition-all duration-300 flex items-center justify-center shadow-lg disabled:opacity-50 transform hover:scale-110 animate-bounce"
                      title="Export to Financial Assets"
                    >
                      {exportingId === message.id ? (
                        <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <Download className="w-3 h-3" />
                      )}
                    </button>
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex items-start space-x-3 animate-fade-in">
              <div className="w-10 h-10 bg-gradient-to-r from-gray-100 to-blue-100 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                <Bot className="w-4 h-4 text-blue-600" />
              </div>
              <div className="bg-gradient-to-r from-gray-100 to-blue-50 rounded-2xl p-4 shadow-lg border border-gray-200">
                <div className="flex space-x-1">
                  <div className="w-3 h-3 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full animate-bounce"></div>
                  <div className="w-3 h-3 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-3 h-3 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        <div className="border-t border-gray-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="flex-1">
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about your portfolio, investments, spending, or savings..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                rows={1}
                disabled={isLoading}
              />
            </div>
            <button
              onClick={toggleRecording}
              disabled={isLoading}
              className={`w-12 h-12 rounded-lg flex items-center justify-center transition-colors duration-200 ${
                isRecording
                  ? "bg-red-600 text-white hover:bg-red-700"
                  : "bg-gray-200 text-gray-600 hover:bg-gray-300"
              } ${isLoading ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <Mic className="w-5 h-5 mx-auto" />
            </button>
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl hover:from-blue-600 hover:to-purple-600 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <Send className="w-5 h-5 mx-auto" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;