import React from 'react';
import { Star, TrendingUp } from 'lucide-react';
import { apiService } from '../services/api';
import { useApi } from '../hooks/useApi';

const StockRecommendations: React.FC = () => {
  const { data: recommendations, loading, error } = useApi(() => apiService.getStockRecommendations());

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse">
          <div className="flex items-center justify-between mb-6">
            <div className="h-6 bg-gray-200 rounded w-1/2"></div>
            <div className="w-5 h-5 bg-gray-200 rounded"></div>
          </div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex justify-between mb-2">
                  <div>
                    <div className="h-4 bg-gray-200 rounded w-16 mb-1"></div>
                    <div className="h-3 bg-gray-200 rounded w-32"></div>
                  </div>
                  <div>
                    <div className="h-4 bg-gray-200 rounded w-20 mb-1"></div>
                    <div className="h-3 bg-gray-200 rounded w-12"></div>
                  </div>
                </div>
                <div className="flex justify-between">
                  <div className="h-6 bg-gray-200 rounded w-16"></div>
                  <div className="h-3 bg-gray-200 rounded w-24"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || !recommendations) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="text-red-600 text-center">
          <p>Error loading stock recommendations</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Mutual Fund Holdings</h3>
        <Star className="w-5 h-5 text-yellow-500" />
      </div>
      
      <div className="space-y-4">
        {recommendations.map((stock, index) => (
          <div key={index} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow duration-200">
            <div className="flex items-start justify-between mb-2">
              <div>
                <div className="font-semibold text-gray-900">{stock.symbol}</div>
                <div className="text-sm text-gray-600">{stock.name}</div>
              </div>
              <div className="text-right">
                <div className="font-medium text-gray-900">{stock.price}</div>
                <div className="text-sm text-green-600 flex items-center space-x-1">
                  <TrendingUp className="w-3 h-3" />
                  <span>{stock.potential}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className={`px-2 py-1 text-xs rounded-full ${
                stock.rating === 'Strong Buy' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-blue-100 text-blue-800'
              }`}>
                {stock.rating}
              </span>
              <span className="text-xs text-gray-600">{stock.reason}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StockRecommendations;