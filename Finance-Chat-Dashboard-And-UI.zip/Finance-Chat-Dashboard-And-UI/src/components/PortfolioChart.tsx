import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface PortfolioChartProps {
  portfolioData: Array<{
    symbol: string;
    name: string;
    value: number;
    change: number;
    changePercent: number;
  }>;
}

const PortfolioChart: React.FC<PortfolioChartProps> = ({ portfolioData }) => {
  // Generate mock historical data for the last 30 days
  const generateHistoricalData = (currentValue: number, changePercent: number) => {
    const data = [];
    const days = 30;
    
    for (let i = days; i >= 0; i--) {
      // Create realistic fluctuations around the trend
      const randomVariation = (Math.random() - 0.5) * 0.02; // ±1% random variation
      const trendFactor = (changePercent / 100) * (days - i) / days;
      const baseValue = currentValue / (1 + changePercent / 100);
      const dayValue = baseValue * (1 + trendFactor + randomVariation);
      data.push(Math.round(dayValue));
    }
    
    return data;
  };

  // Generate labels for the last 30 days
  const labels = Array.from({ length: 31 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (30 - i));
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  });

  const colors = [
    'rgba(59, 130, 246, 0.8)', // Blue
    'rgba(16, 185, 129, 0.8)', // Green
    'rgba(245, 101, 101, 0.8)', // Red
    'rgba(139, 92, 246, 0.8)', // Purple
  ];

  const datasets = portfolioData.map((stock, index) => ({
    label: stock.symbol,
    data: generateHistoricalData(stock.value, stock.changePercent),
    borderColor: colors[index % colors.length],
    backgroundColor: colors[index % colors.length].replace('0.8', '0.1'),
    borderWidth: 2,
    fill: false,
    tension: 0.4,
    pointRadius: 0,
    pointHoverRadius: 6,
    pointHoverBackgroundColor: colors[index % colors.length],
    pointHoverBorderColor: '#fff',
    pointHoverBorderWidth: 2,
  }));

  const data = {
    labels,
    datasets,
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          usePointStyle: true,
          padding: 20,
          font: {
            size: 12,
          },
        },
      },
      tooltip: {
        mode: 'index' as const,
        intersect: false,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        borderWidth: 1,
        cornerRadius: 8,
        displayColors: true,
        callbacks: {
          label: function(context: any) {
            return `${context.dataset.label}: $${context.parsed.y.toLocaleString()}`;
          },
        },
      },
    },
    scales: {
      x: {
        display: true,
        grid: {
          display: false,
        },
        ticks: {
          maxTicksLimit: 8,
          color: '#6B7280',
          font: {
            size: 11,
          },
        },
      },
      y: {
        display: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          color: '#6B7280',
          font: {
            size: 11,
          },
          callback: function(value: any) {
            return '$' + value.toLocaleString();
          },
        },
      },
    },
    interaction: {
      mode: 'nearest' as const,
      axis: 'x' as const,
      intersect: false,
    },
    elements: {
      point: {
        hoverRadius: 8,
      },
    },
  };

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-medium text-gray-900">30-Day Performance Trend</h4>
        <div className="text-xs text-gray-500">Hover over the chart for details</div>
      </div>
      <div className="h-64 w-full">
        <Line data={data} options={options} />
      </div>
      <div className="mt-4 text-xs text-gray-500 text-center">
        Track your portfolio's performance over the last 30 days with real-time trend analysis
      </div>
    </div>
  );
};

export default PortfolioChart;