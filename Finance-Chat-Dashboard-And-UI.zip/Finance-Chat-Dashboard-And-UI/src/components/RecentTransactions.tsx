import React from 'react';
import { ArrowUpRight, ArrowDownLeft, DollarSign } from 'lucide-react';
import { apiService } from '../services/api';
import { useApi } from '../hooks/useApi';

const RecentTransactions: React.FC = () => {
  const { data: transactions, loading, error } = useApi(() => apiService.getRecentTransactions());

  const getIcon = (type: string) => {
    switch (type) {
      case 'buy':
        return <ArrowDownLeft className="w-4 h-4 text-red-600" />;
      case 'sell':
        return <ArrowUpRight className="w-4 h-4 text-green-600" />;
      case 'dividend':
        return <DollarSign className="w-4 h-4 text-blue-600" />;
      default:
        return <DollarSign className="w-4 h-4 text-gray-600" />;
    }
  };

  const getAmountColor = (type: string) => {
    switch (type) {
      case 'buy':
        return 'text-red-600';
      case 'sell':
      case 'dividend':
        return 'text-green-600';
      default:
        return 'text-gray-600';
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/2 mb-6"></div>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/3 mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
                <div className="h-4 bg-gray-200 rounded w-16"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || !transactions) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="text-red-600 text-center">
          <p>Error loading transactions</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Recent Transactions</h3>
      
      <div className="space-y-4">
        {transactions.map((transaction, index) => (
          <div key={index} className="flex items-center space-x-4 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-150">
            <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
              {getIcon(transaction.type)}
            </div>
            <div className="flex-1">
              <div className="font-medium text-gray-900">{transaction.description}</div>
              <div className="text-sm text-gray-600">{transaction.shares}</div>
              <div className="text-xs text-gray-500">{transaction.date}</div>
            </div>
            <div className={`font-medium ${getAmountColor(transaction.type)}`}>
              {transaction.type === 'buy' ? '-' : '+'}${transaction.amount.toLocaleString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentTransactions;