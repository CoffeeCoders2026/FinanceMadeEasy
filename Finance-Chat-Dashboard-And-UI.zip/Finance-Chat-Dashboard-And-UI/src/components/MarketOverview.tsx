import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { apiService } from '../services/api';
import { useApi } from '../hooks/useApi';

const MarketOverview: React.FC = () => {
  const { data: marketData, loading, error } = useApi(() => apiService.getMarketData());

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/2 mb-6"></div>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex justify-between">
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                <div className="h-4 bg-gray-200 rounded w-1/6"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || !marketData) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="text-red-600 text-center">
          <p>Error loading market data</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Market Overview</h3>
      
      <div className="space-y-4">
        {marketData.map((market, index) => (
          <div key={index} className="flex items-center justify-between">
            <div>
              <div className="font-medium text-gray-900">{market.name}</div>
              <div className="text-sm text-gray-600">{market.value}</div>
            </div>
            <div className={`flex items-center space-x-1 text-sm ${
              market.positive ? 'text-green-600' : 'text-red-600'
            }`}>
              {market.positive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              <span>{market.change}</span>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h4 className="font-medium text-blue-900 mb-2">Market Insight</h4>
        <p className="text-sm text-blue-800">
          Tech stocks are showing strong performance today, with the NASDAQ leading gains.
        </p>
      </div>
    </div>
  );
};

export default MarketOverview;