import React from 'react';
import { ShoppingCart, Car, Home, Coffee } from 'lucide-react';
import { apiService } from '../services/api';
import { useApi } from '../hooks/useApi';
import SpendingCharts from './SpendingCharts';

const SpendingAnalysis: React.FC = () => {
  const { data, loading, error } = useApi(() => apiService.getSpendingData());

  const iconMap = {
    ShoppingCart,
    Car,
    Home,
    Coffee,
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/2 mb-6"></div>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-1/3 mb-2"></div>
                  <div className="h-2 bg-gray-200 rounded w-full"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="text-red-600 text-center">
          <p>Error loading spending data</p>
        </div>
      </div>
    );
  }

  const { spending: spendingData, total } = data;

  return (
    <div className="bg-gradient-to-br from-white to-purple-50 rounded-xl shadow-lg border border-purple-100 p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          Spending Analysis
        </h3>
        <span className="text-sm bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent font-medium">
          This Month
        </span>
      </div>
      
      <div className="space-y-4">
        {spendingData.map((item, index) => {
          const Icon = iconMap[item.icon as keyof typeof iconMap] || ShoppingCart;
          const percentage = ((item.amount / total) * 100).toFixed(1);
          
          return (
            <div key={index} className="flex items-center space-x-4 p-3 rounded-xl bg-gradient-to-r from-white to-gray-50 hover:from-gray-50 hover:to-purple-50 transition-all duration-300 transform hover:scale-102 border border-gray-100 hover:border-purple-200">
              <div className={`w-12 h-12 ${item.color} rounded-xl flex items-center justify-center shadow-lg transform hover:rotate-12 transition-transform duration-300`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-gray-900">{item.category}</span>
                  <span className="font-bold text-gray-900">${item.amount}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                  <div
                    className={`${item.color} h-3 rounded-full transition-all duration-1000 ease-out animate-pulse`}
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
                <div className="text-xs font-medium text-gray-600 mt-1">{percentage}% of total</div>
              </div>
            </div>
          );
        })}
      </div>
      
      <SpendingCharts spendingData={spendingData} total={total} />
    </div>
  );
};

export default SpendingAnalysis;