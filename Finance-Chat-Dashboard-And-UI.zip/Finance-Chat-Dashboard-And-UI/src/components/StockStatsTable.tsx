import React from 'react';

const STOCKS = [
  {
    symbol: 'AAPL',
    name: 'Apple Inc.',
    peRatio: 28.5,
    profitMargin: '21.7%',
    movingAverage50: 185.23,
    beta: 1.29,
    high52: 199.62,
    low52: 149.22,
  },
  {
    symbol: 'GOOGL',
    name: 'Alphabet Inc.',
    peRatio: 25.1,
    profitMargin: '22.5%',
    movingAverage50: 2735.12,
    beta: 1.05,
    high52: 2950.00,
    low52: 2250.10,
  },
  {
    symbol: 'MSFT',
    name: 'Microsoft Corp.',
    peRatio: 32.7,
    profitMargin: '35.3%',
    movingAverage50: 320.45,
    beta: 0.92,
    high52: 349.67,
    low52: 280.12,
  },
  {
    symbol: 'TSLA',
    name: 'Tesla Inc.',
    peRatio: 70.2,
    profitMargin: '15.1%',
    movingAverage50: 720.33,
    beta: 2.01,
    high52: 900.40,
    low52: 550.20,
  },
  {
    symbol: 'AMZN',
    name: 'Amazon.com Inc.',
    peRatio: 60.8,
    profitMargin: '6.3%',
    movingAverage50: 3400.12,
    beta: 1.15,
    high52: 3773.08,
    low52: 2881.00,
  },
];

const StockStatsTable: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-8 animate-slide-up">
      <h3 className="text-lg font-semibold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
        Stock Key Statistics
      </h3>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">PE Ratio</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Profit Margin</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">50D MA</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Beta</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">52W High</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">52W Low</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-100">
            {STOCKS.map((stock) => (
              <tr key={stock.symbol} className="hover:bg-blue-50 transition-colors">
                <td className="px-4 py-2 whitespace-nowrap">
                  <div className="font-bold text-gray-900">{stock.symbol}</div>
                  <div className="text-xs text-gray-500">{stock.name}</div>
                </td>
                <td className="px-4 py-2">{stock.peRatio}</td>
                <td className="px-4 py-2">{stock.profitMargin}</td>
                <td className="px-4 py-2">{stock.movingAverage50}</td>
                <td className="px-4 py-2">{stock.beta}</td>
                <td className="px-4 py-2">{stock.high52}</td>
                <td className="px-4 py-2">{stock.low52}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StockStatsTable;
