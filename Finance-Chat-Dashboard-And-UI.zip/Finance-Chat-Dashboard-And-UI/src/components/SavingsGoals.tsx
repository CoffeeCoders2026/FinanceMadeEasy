import React from 'react';
import { Target, Plane, Home, GraduationCap } from 'lucide-react';
import { apiService } from '../services/api';
import { useApi } from '../hooks/useApi';

const SavingsGoals: React.FC = () => {
  const { data: goals, loading, error } = useApi(() => apiService.getSavingsGoals());

  const iconMap = {
    Target,
    Plane,
    Home,
    GraduationCap,
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/2 mb-6"></div>
          <div className="space-y-6">
            {[...Array(4)].map((_, i) => (
              <div key={i}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-200 rounded-lg"></div>
                    <div className="h-4 bg-gray-200 rounded w-24"></div>
                  </div>
                  <div className="h-4 bg-gray-200 rounded w-16"></div>
                </div>
                <div className="h-3 bg-gray-200 rounded w-full"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || !goals) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="text-red-600 text-center">
          <p>Error loading savings goals</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-white to-green-50 rounded-xl shadow-lg border border-green-100 p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <h3 className="text-lg font-semibold bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent mb-6">
        Savings Goals
      </h3>
      
      <div className="space-y-6">
        {goals.map((goal, index) => {
          const Icon = iconMap[goal.icon as keyof typeof iconMap] || Target;
          const progress = (goal.current / goal.target) * 100;
          
          return (
            <div key={index} className="p-4 rounded-xl bg-gradient-to-r from-white to-gray-50 hover:from-gray-50 hover:to-green-50 transition-all duration-300 border border-gray-100 hover:border-green-200">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 ${goal.color} rounded-xl flex items-center justify-center shadow-lg transform hover:rotate-12 transition-transform duration-300`}>
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-semibold text-gray-900">{goal.name}</span>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-gray-900">${goal.current.toLocaleString()}</div>
                  <div className="text-xs text-gray-600">${goal.target.toLocaleString()}</div>
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden shadow-inner">
                <div
                  className={`${goal.color} h-4 rounded-full transition-all duration-1000 ease-out animate-pulse shadow-sm`}
                  style={{ width: `${Math.min(progress, 100)}%` }}
                ></div>
              </div>
              <div className="text-xs font-medium text-gray-600 mt-2">{progress.toFixed(1)}% complete</div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SavingsGoals;