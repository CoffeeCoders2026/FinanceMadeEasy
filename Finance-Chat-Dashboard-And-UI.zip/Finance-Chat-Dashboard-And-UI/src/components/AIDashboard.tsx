import React from 'react';
import StockAnalysisTable from './StockAnalysisTable';
import PortfolioOverview from './PortfolioOverview';
import MarketOverview from './MarketOverview';

const AIDashboard: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 min-h-screen animate-fade-in">
      <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-8">
        Insights
      </h2>
      <div className="grid grid-cols-1 gap-6 mb-8">
        <div className="lg:col-span-2">
          <h3 className="text-2xl font-semibold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent mb-4">
            Tailored Stock Picks for Your Risk Profile
          </h3>
          <StockAnalysisTable />
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <PortfolioOverview />
        </div>
        <div>
          <MarketOverview />
        </div>
      </div>
    </div>
  );
};

export default AIDashboard;
