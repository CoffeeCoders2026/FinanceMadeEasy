import { ExportedSuggestion } from '../types';

class StorageService {
  private readonly STORAGE_KEY = 'financial_assets';

  getExportedSuggestions(): ExportedSuggestion[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (!stored) return [];
      
      const parsed = JSON.parse(stored);
      return parsed.map((item: any) => ({
        ...item,
        exportedAt: new Date(item.exportedAt)
      }));
    } catch (error) {
      console.error('Error loading exported suggestions:', error);
      return [];
    }
  }

  saveExportedSuggestion(suggestion: ExportedSuggestion): void {
    try {
      const existing = this.getExportedSuggestions();
      const updated = [suggestion, ...existing];
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error saving exported suggestion:', error);
      throw new Error('Failed to save suggestion');
    }
  }

  deleteExportedSuggestion(id: string): void {
    try {
      const existing = this.getExportedSuggestions();
      const filtered = existing.filter(item => item.id !== id);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filtered));
    } catch (error) {
      console.error('Error deleting exported suggestion:', error);
      throw new Error('Failed to delete suggestion');
    }
  }

  clearAllExportedSuggestions(): void {
    try {
      localStorage.removeItem(this.STORAGE_KEY);
    } catch (error) {
      console.error('Error clearing exported suggestions:', error);
      throw new Error('Failed to clear suggestions');
    }
  }
}

export const storageService = new StorageService();