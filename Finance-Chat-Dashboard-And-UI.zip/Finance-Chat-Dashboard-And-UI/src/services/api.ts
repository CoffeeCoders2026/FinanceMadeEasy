const API_BASE_URL = 'http://localhost:3001/api';

// Auth token management
let authToken: string | null = localStorage.getItem('auth_token');

export const setAuthToken = (token: string | null) => {
  authToken = token;
  if (token) {
    localStorage.setItem('auth_token', token);
  } else {
    localStorage.removeItem('auth_token');
  }
};

export const getAuthToken = () => authToken;

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

class ApiService {
  private async fetchData<T>(endpoint: string, options?: RequestInit): Promise<T> {
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...options?.headers,
      };

      // Add auth token if available
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }

      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        headers,
        ...options,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result: ApiResponse<T> = await response.json();
      
      if (!result.success) {
        throw new Error(result.error || 'API request failed');
      }

      return result.data as T;
    } catch (error) {
      console.error(`API Error for ${endpoint}:`, error);
      throw error;
    }
  }

  // Authentication methods
  async login(email: string, password: string) {
    return this.fetchData<{
      token: string;
      user: {
        id: string;
        email: string;
        firstName: string;
        lastName: string;
      };
      chatHistory: Array<{
        id: string;
        type: 'user' | 'assistant';
        content: string;
        timestamp: string;
      }>;
    }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  }

  async register(email: string, password: string, firstName: string, lastName: string) {
    return this.fetchData<{
      token: string;
      user: {
        id: string;
        email: string;
        firstName: string;
        lastName: string;
      };
    }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, firstName, lastName }),
    });
  }

  async logout() {
    return this.fetchData<{
      message: string;
    }>('/auth/logout', {
      method: 'POST',
    });
  }

  async getCurrentUser() {
    return this.fetchData<{
      user: {
        id: string;
        email: string;
        firstName: string;
        lastName: string;
      };
      chatHistory: Array<{
        id: string;
        type: 'user' | 'assistant';
        content: string;
        timestamp: string;
      }>;
    }>('/auth/me');
  }

  async getPortfolio() {
    return this.fetchData<{
      portfolio: Array<{
        symbol: string;
        name: string;
        value: number;
        change: number;
        changePercent: number;
      }>;
      totalValue: number;
      totalChange: number;
    }>('/portfolio');
  }

  async getMarketData() {
    return this.fetchData<Array<{
      name: string;
      value: string;
      change: string;
      positive: boolean;
    }>>('/market');
  }

  async getSpendingData() {
    return this.fetchData<{
      spending: Array<{
        category: string;
        amount: number;
        icon: string;
        color: string;
      }>;
      total: number;
    }>('/spending');
  }

  async getSavingsGoals() {
    return this.fetchData<Array<{
      name: string;
      target: number;
      current: number;
      icon: string;
      color: string;
    }>>('/savings');
  }

  async getStockRecommendations() {
    return this.fetchData<Array<{
      symbol: string;
      name: string;
      price: string;
      rating: string;
      potential: string;
      reason: string;
    }>>('/recommendations');
  }

  async getRecentTransactions() {
    return this.fetchData<Array<{
      type: string;
      description: string;
      amount: number;
      date: string;
      shares: string;
    }>>('/transactions');
  }

  async sendChatMessage(message: string) {
    return this.fetchData<{
      response: string;
      timestamp: string;
      chatHistory: Array<{
        id: string;
        type: 'user' | 'assistant';
        content: string;
        timestamp: string;
      }>;
    }>('/chat', {
      method: 'POST',
      body: JSON.stringify({ message }),
    });
  }

  async getChatHistory() {
    return this.fetchData<{
      chatHistory: Array<{
        id: string;
        type: 'user' | 'assistant';
        content: string;
        timestamp: string;
      }>;
    }>('/chat/history');
  }

  async clearChatHistory() {
    return this.fetchData<{
      message: string;
    }>('/chat/clear', {
      method: 'POST',
    });
  }

  async checkHealth() {
    return this.fetchData<{
      message: string;
      timestamp: string;
    }>('/health');
  }
}

export const apiService = new ApiService();