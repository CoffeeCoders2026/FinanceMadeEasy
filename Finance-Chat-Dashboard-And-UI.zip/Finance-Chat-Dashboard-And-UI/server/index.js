const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const fs = require("fs").promises; // Add fs for file operations
const path = require("path");
const request = require("request");
require("dotenv").config();
const { GoogleGenAI } = require("@google/genai");

const app = express();
const PORT = process.env.PORT || 3001;
const appName = "FinanceMadeEasy";
let globalSessionsss = "";

// Path to store chat history
const CHAT_HISTORY_FILE = path.join(__dirname, "chat_history.json");

// Initialize Google Gemini AI
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "YOUR_GEMINI_API_KEY"
});

// Middleware
app.use(cors());
app.use(express.json());

// In-memory user storage (in production, use a proper database)
const users = [
  {
    id: "1",
    email: "demo@financeai.com",
    password: "password123",
    firstName: "Alex",
    lastName: "Johnson",
    phone: "4444444444",
    session_id: "mcp-session-594e48ea-fea1-40ef-8c52-7552dd927679",
    createdAt: new Date("2024-01-01"),
  },
  {
    id: "2",
    email: "test@test.com",
    password: "test",
    firstName: "Test",
    lastName: "User",
    phone: "1010101010",
    session_id: "mcp-session-594e48ea-fea1-40ef-8c52-7552dd9272af",
    createdAt: new Date("2024-01-15"),
  },
  {
    id: "3",
    email: "coffeecoders2026@gmail.com",
    password: "test",
    firstName: "Coffee",
    lastName: "Coders",
    phone: "1414141414",
    session_id: "mcp-session-594e48ea-fea1-40ef-8c52-7552dd9273ef",
    createdAt: new Date("2024-01-15"),
  }
];

// In-memory session storage (in production, use Redis or similar)
const sessions = new Map();

// Helper function to generate session token
const generateSessionToken = () => {
  return crypto.randomBytes(32).toString("hex");
};

// Helper function to load chat history from file
const loadChatHistory = async () => {
  try {
    const data = await fs.readFile(CHAT_HISTORY_FILE, "utf8");
    return JSON.parse(data);
  } catch (error) {
    if (error.code === "ENOENT") {
      // File doesn't exist, initialize empty
      return {};
    }
    console.error("Error loading chat history:", error);
    return {};
  }
};

// Helper function to save chat history to file
const saveChatHistory = async (history) => {
  try {
    await fs.writeFile(CHAT_HISTORY_FILE, JSON.stringify(history, null, 2));
  } catch (error) {
    console.error("Error saving chat history:", error);
  }
};

// Initialize chat history
let chatHistory = {};

// Load chat history on server start
(async () => {
  chatHistory = await loadChatHistory();
})();

// Middleware to check authentication
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res
      .status(401)
      .json({ success: false, error: "Access token required" });
  }

  const session = sessions.get(token);
  if (!session || session.expiresAt < new Date()) {
    sessions.delete(token);
    return res
      .status(401)
      .json({ success: false, error: "Invalid or expired token" });
  }

  req.user = session.user;
  next();
};

// Mock data
const portfolioData = {
  "demo@financeai.com": [
    {
      symbol: "AAPL",
      name: "Apple Inc.",
      value: 15420,
      change: 2.34,
      changePercent: 5.2,
    },
    {
      symbol: "GOOGL",
      name: "Alphabet Inc.",
      value: 8950,
      change: -1.23,
      changePercent: -2.1,
    },
    {
      symbol: "MSFT",
      name: "Microsoft Corp.",
      value: 12100,
      change: 3.45,
      changePercent: 1.8,
    },
    {
      symbol: "TSLA",
      name: "Tesla Inc.",
      value: 6700,
      change: 12.67,
      changePercent: 8.9,
    },
  ],
  "test@test.com": [
    {
      symbol: "TATA",
      name: "Tata Corp.",
      value: 13420,
      change: 2.34,
      changePercent: 5.2,
    },
    {
      symbol: "GOOGL",
      name: "Alphabet Inc.",
      value: 7130,
      change: -1.23,
      changePercent: -2.1,
    },
    {
      symbol: "NVDA",
      name: "Nvidia Corp.",
      value: 9500,
      change: 5.11,
      changePercent: 5.8,
    },
    {
      symbol: "WLMRT",
      name: "Walmart Corp.",
      value: 7700,
      change: 13.27,
      changePercent: 6.9,
    },
  ],
  "coffeecoders2026@gmail.com": [
    {
      symbol: "NO STOCK HOLDINGS",
      name: "N/A",
      value: 0,
      change: 0,
      changePercent: 0,
    }
  ]
};

const marketData = [
  { name: "S&P 500", value: "4,567.89", change: "+1.2%", positive: true },
  { name: "NASDAQ", value: "14,239.88", change: "+0.8%", positive: true },
  { name: "DOW", value: "35,089.74", change: "-0.3%", positive: false },
  { name: "Bitcoin", value: "$43,285", change: "+3.4%", positive: true },
];

const spendingData = {
  "demo@financeai.com": [
    {
      category: "Shopping",
      amount: 1240,
      icon: "ShoppingCart",
      color: "bg-blue-500",
    },
    {
      category: "Transportation",
      amount: 680,
      icon: "Car",
      color: "bg-green-500",
    },
    { category: "Housing", amount: 2100, icon: "Home", color: "bg-purple-500" },
    {
      category: "Food & Dining",
      amount: 890,
      icon: "Coffee",
      color: "bg-orange-500",
    },
  ],
  "test@test.com": [
    {
      category: "Shopping",
      amount: 2710,
      icon: "ShoppingCart",
      color: "bg-blue-500",
    },
    {
      category: "Transportation",
      amount: 1680,
      icon: "Car",
      color: "bg-green-500",
    },
    { category: "Housing", amount: 3500, icon: "Home", color: "bg-purple-500" },
    {
      category: "Food & Dining",
      amount: 950,
      icon: "Coffee",
      color: "bg-orange-500",
    },
  ],
  "coffeecoders2026@gmail.com": [
    {
      category: "Home Loan",
      amount: 80000,
      icon: "Home",
      color: "bg-blue-500",
    },
    {
      category: "House Renovation",
      amount: 35000,
      icon: "Home",
      color: "bg-green-500",
    }
  ]
};

const savingsGoals = {
  "demo@financeai.com": [
    {
      name: "Emergency Fund",
      target: 15000,
      current: 8500,
      icon: "Target",
      color: "bg-red-500",
    },
    {
      name: "Vacation",
      target: 5000,
      current: 3200,
      icon: "Plane",
      color: "bg-blue-500",
    },
    {
      name: "House Down Payment",
      target: 50000,
      current: 18000,
      icon: "Home",
      color: "bg-green-500",
    },
    {
      name: "Education",
      target: 8000,
      current: 6400,
      icon: "GraduationCap",
      color: "bg-purple-500",
    },
  ],
  "test@test.com": [
    {
      name: "Emergency Fund",
      target: 35000,
      current: 18500,
      icon: "Target",
      color: "bg-red-500",
    },
    {
      name: "Vacation",
      target: 6000,
      current: 1200,
      icon: "Plane",
      color: "bg-blue-500",
    },
    {
      name: "House Down Payment",
      target: 43000,
      current: 28000,
      icon: "Home",
      color: "bg-green-500",
    },
    {
      name: "Education",
      target: 3000,
      current: 500,
      icon: "GraduationCap",
      color: "bg-purple-500",
    },
  ],
  "coffeecoders2026@gmail.com": [
    {
      name: "Emergency Fund",
      target: 300000,
      current: 125000,
      icon: "Target",
      color: "bg-red-500",
    },
    {
      name: "Vacation",
      target: 2000,
      current: 200,
      icon: "Plane",
      color: "bg-blue-500",
    },
    {
      name: "Education",
      target: 30000,
      current: 12000,
      icon: "GraduationCap",
      color: "bg-purple-500",
    },
  ]
};

const stockRecommendations = {
  "demo@financeai.com": [
    {
      symbol: "NVDA",
      name: "NVIDIA Corporation",
      price: "$2175.43",
      rating: "Best performing",
      potential: "+18%",
      reason: "AI chip demand surge",
    },
    {
      symbol: "AMD",
      name: "Advanced Micro Devices",
      price: "$1420.67",
      rating: "Performing good",
      potential: "+12%",
      reason: "Server market growth",
    },
    {
      symbol: "AMZN",
      name: "Amazon.com Inc.",
      price: "$3,145.89",
      rating: "Average",
      potential: "+5%",
      reason: "Cloud services expansion",
    },
    {
      symbol: "OPAI",
      name: "Open AI",
      price: "$513.89",
      rating: "Best performing",
      potential: "+28%",
      reason: "AI services expansion",
    },
  ],
  "test@test.com": [
    {
      symbol: "WHTOK",
      name: "White Oak Corporations",
      price: "$2730.43",
      rating: "Average",
      potential: "+6%",
      reason: "Online Education demand surge",
    },
    {
      symbol: "AMD",
      name: "Advanced Micro Devices",
      price: "$542.67",
      rating: "Performing Good",
      potential: "+12%",
      reason: "Server market growth",
    },
    {
      symbol: "AMZN",
      name: "Amazon.com Inc.",
      price: "$745.89",
      rating: "Best performing",
      potential: "+15%",
      reason: "Cloud services expansion",
    },
  ],
  "coffeecoders2026@gmail.com": [
    {
      symbol: "NVDA",
      name: "NVIDIA Corporation",
      price: "$875.43",
      rating: "Best performing",
      potential: "+18%",
      reason: "AI chip demand surge",
    },
    {
      symbol: "AMD",
      name: "Advanced Micro Devices",
      price: "$1420.67",
      rating: "Performing good",
      potential: "+12%",
      reason: "Server market growth",
    },
    {
      symbol: "AMZN",
      name: "Amazon.com Inc.",
      price: "$745.89",
      rating: "Best performing",
      potential: "+15%",
      reason: "Cloud services expansion",
    },
    {
      symbol: "OPAI",
      name: "Open AI",
      price: "$513.89",
      rating: "Best performing",
      potential: "+28%",
      reason: "AI services expansion",
    }
  ]
};

const recentTransactions = {
  "demo@financeai.com": [
    {
      type: "buy",
      description: "AAPL - Apple Inc.",
      amount: 2500,
      date: "Today, 2:30 PM",
      shares: "8 shares @ $312.50",
    },
    {
      type: "sell",
      description: "TSLA - Tesla Inc.",
      amount: 1800,
      date: "Yesterday, 11:15 AM",
      shares: "6 shares @ $300.00",
    },
    {
      type: "dividend",
      description: "MSFT Dividend",
      amount: 89.5,
      date: "Dec 15, 9:00 AM",
      shares: "Quarterly dividend",
    },
    {
      type: "buy",
      description: "GOOGL - Alphabet Inc.",
      amount: 3200,
      date: "Dec 14, 1:45 PM",
      shares: "2 shares @ $1,600.00",
    },
  ],
  "test@test.com": [
    {
      type: "buy",
      description: "AAPL - Apple Inc.",
      amount: 2500,
      date: "Today, 2:30 PM",
      shares: "8 shares @ $312.50",
    },
    {
      type: "sell",
      description: "TSLA - Tesla Inc.",
      amount: 1800,
      date: "Yesterday, 11:15 AM",
      shares: "6 shares @ $300.00",
    },
    {
      type: "dividend",
      description: "MSFT Dividend",
      amount: 89.5,
      date: "Dec 15, 9:00 AM",
      shares: "Quarterly dividend",
    },
    {
      type: "buy",
      description: "GOOGL - Alphabet Inc.",
      amount: 3200,
      date: "Dec 14, 1:45 PM",
      shares: "2 shares @ $1,600.00",
    },
  ],
  "coffeecoders2026@gmail.com": [
    {
      type: "no transaction",
      description: "N/A",
      amount: 0,
      date: "N/A",
      shares: "N/A",
    }
  ]
};

// Authentication Routes
app.post("/api/auth/register", async (req, res) => {
  try {
    const { email, password, firstName, lastName } = req.body;

    if (!email || !password || !firstName || !lastName) {
      return res.status(400).json({
        success: false,
        error: "All fields are required",
      });
    }

    const existingUser = users.find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: "User with this email9566 already exists",
      });
    }

    const newUser = {
      id: (users.length + 1).toString(),
      email: email.toLowerCase(),
      password,
      firstName,
      lastName,
      createdAt: new Date(),
    };

    users.push(newUser);

    const sessionToken = generateSessionToken();
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    sessions.set(sessionToken, {
      user: {
        id: newUser.id,
        email: newUser.email,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
      },
      expiresAt,
      chatHistory: [], // Initialize empty chat history for new user
    });

    // Save to file-based chat history
    chatHistory[newUser.id] = [];
    await saveChatHistory(chatHistory);

    res.json({
      success: true,
      data: {
        token: sessionToken,
        user: {
          id: newUser.id,
          email: newUser.email,
          firstName: newUser.firstName,
          lastName: newUser.lastName,
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: "Registration failed" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: "Email and password are required",
      });
    }

    const user = users.find(
      (u) =>
        u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );

    if (!user) {
      return res.status(401).json({
        success: false,
        error: "Invalid email or password",
      });
    }

    const sessionToken = generateSessionToken();
    globalSessionsss = sessionToken;
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    // Load chat history for user or initialize empty
    const userChatHistory = chatHistory[user.id] || [];

    sessions.set(sessionToken, {
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        session_id: user.session_id,
      },
      expiresAt,
      chatHistory: userChatHistory,
    });

    res.json({
      success: true,
      data: {
        token: sessionToken,
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
        },
        chatHistory: userChatHistory, // Return chat history on login
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: "Login failed" });
  }
});

app.post("/api/auth/logout", authenticateToken, async (req, res) => {
  try {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];

    if (token) {
      // Save chat history to file before deleting session
      const session = sessions.get(token);
      if (session && session.chatHistory) {
        chatHistory[session.user.id] = session.chatHistory;
        await saveChatHistory(chatHistory);
      }
      sessions.delete(token);
    }

    res.json({
      success: true,
      message: "Logged out successfully",
    });
  } catch (error) {
    res.status(500).json({ success: false, error: "Logout failed" });
  }
});

app.get("/api/auth/me", authenticateToken, (req, res) => {
  try {
    res.json({
      success: true,
      data: {
        user: req.user,
        chatHistory: sessions.get(req.headers["authorization"].split(" ")[1]).chatHistory || [],
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: "Failed to get user info" });
  }
});

// API Routes
app.get("/api/portfolio", (req, res) => {
  try {
    let userDetails = sessions.get(globalSessionsss);
    const totalValue = portfolioData[userDetails.user.email].reduce(
      (sum, stock) => sum + stock.value,
      0
    );
    const totalChange = portfolioData[userDetails.user.email].reduce(
      (sum, stock) => sum + stock.change,
      0
    );

    res.json({
      success: true,
      data: {
        portfolio: portfolioData[userDetails.user.email],
        totalValue,
        totalChange,
      },
    });
  } catch (error) {
    res
      .status(500)
      .json({ success: false, error: "Failed to fetch portfolio data" });
  }
});

app.get("/api/market", (req, res) => {
  try {
    res.json({
      success: true,
      data: marketData,
    });
  } catch (error) {
    res
      .status(500)
      .json({ success: false, error: "Failed to fetch market data" });
  }
});

app.get("/api/spending", (req, res) => {
  let userDetails = sessions.get(globalSessionsss);
  try {
    const total = spendingData[userDetails.user.email].reduce(
      (sum, item) => sum + item.amount,
      0
    );

    res.json({
      success: true,
      data: {
        spending: spendingData[userDetails.user.email],
        total,
      },
    });
  } catch (error) {
    res
      .status(500)
      .json({ success: false, error: "Failed to fetch spending data" });
  }
});

app.get("/api/savings", (req, res) => {
  let userDetails = sessions.get(globalSessionsss);
  try {
    res.json({
      success: true,
      data: savingsGoals[userDetails.user.email],
    });
  } catch (error) {
    res
      .status(500)
      .json({ success: false, error: "Failed to fetch savings data" });
  }
});

app.get("/api/recommendations", (req, res) => {
  let userDetails = sessions.get(globalSessionsss);
  try {
    res.json({
      success: true,
      data: stockRecommendations[userDetails.user.email],
    });
  } catch (error) {
    res
      .status(500)
      .json({ success: false, error: "Failed to fetch recommendations" });
  }
});

app.get("/api/transactions", (req, res) => {
  let userDetails = sessions.get(globalSessionsss);
  try {
    res.json({
      success: true,
      data: recentTransactions[userDetails.user.email],
    });
  } catch (error) {
    res
      .status(500)
      .json({ success: false, error: "Failed to fetch transactions" });
  }
});

// Chat endpoint
app.post("/api/chat", authenticateToken, async (req, res) => {
  function extractMeaningfulResponse(adkResponseArray) {
    if (!Array.isArray(adkResponseArray)) return null;

    for (const item of adkResponseArray) {
      const part = item?.content?.parts?.find(
        (p) => p.functionResponse?.response
      );
      if (part?.functionResponse?.response?.result) {
        return part.functionResponse.response.result;
      }
    }

    for (let i = adkResponseArray.length - 1; i >= 0; i--) {
      const part = adkResponseArray[i]?.content?.parts?.find((p) => p.text);
      if (part?.text) {
        return part.text;
      }
    }

    return null;
  }
  try {
    const { message } = req.body;

    if (!message) {
      return res
        .status(400)
        .json({ success: false, error: "Message is required" });
    }

    const sessionToken = req.headers["authorization"].split(" ")[1];
    const session = sessions.get(sessionToken);

    // Add user message to chat history
    const userMessage = {
      id: Date.now().toString(),
      type: "user",
      content: message,
      timestamp: new Date().toISOString(),
    };
    session.chatHistory.push(userMessage);
    chatHistory[session.user.id] = session.chatHistory;

    const requestBody = {
      appName: appName,
      userId: session.user.phone,
      sessionId: session.user.session_id,
      newMessage: {
        parts: [{ text: message }],
        role: "user",
      },
    };

    const dummyRequestBody = {
      additionalProperty: {},
    };

    fetch(
      `http://127.0.0.1:8000/apps/${appName}/users/${session.user.phone}/sessions/${session.user.session_id}`,
      {
        method: "POST",
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(dummyRequestBody),
      }
    ).catch((error) => {
      console.error("Error calling external API:", error);
    });

    const response = await fetch("http://127.0.0.1:8000/run", {
      method: "POST",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    let responseText =
      "I'm sorry, I couldn't process your request at the moment.";

    if (data && Array.isArray(data) && data.length > 0) {
      const firstResponse = extractMeaningfulResponse(data);
      if (firstResponse) {
        responseText = firstResponse;
      }
    }

    // Add assistant response to chat history
    const assistantMessage = {
      id: (Date.now() + 1).toString(),
      type: "assistant",
      content: responseText,
      timestamp: new Date().toISOString(),
    };
    session.chatHistory.push(assistantMessage);
    chatHistory[session.user.id] = session.chatHistory;

    // Save chat history to file
    await saveChatHistory(chatHistory);

    res.json({
      success: true,
      data: {
        response: responseText,
        timestamp: new Date().toISOString(),
        chatHistory: session.chatHistory,
      },
    });
  } catch (error) {
    console.error("Chat endpoint error:", error);

    const sessionToken = req.headers["authorization"]?.split(" ")[1];
    const session = sessions.get(sessionToken);

    const fallbackResponse =
      "I'm experiencing some technical difficulties right now. Please try again in a moment, or feel free to ask me about your portfolio, spending, investments, or savings goals.";

    if (session) {
      // Add fallback response to chat history
      const assistantMessage = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: fallbackResponse,
        timestamp: new Date().toISOString(),
      };
      session.chatHistory.push(assistantMessage);
      chatHistory[session.user.id] = session.chatHistory;
      await saveChatHistory(chatHistory);
    }

    res.json({
      success: true,
      data: {
        response: fallbackResponse,
        timestamp: new Date().toISOString(),
        chatHistory: session ? session.chatHistory : [],
      },
    });
  }
});

// Get chat history endpoint
app.get("/api/chat/history", authenticateToken, async (req, res) => {
  try {
    const sessionToken = req.headers["authorization"].split(" ")[1];
    const session = sessions.get(sessionToken);
    
    res.json({
      success: true,
      data: {
        chatHistory: session.chatHistory || [],
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: "Failed to fetch chat history" });
  }
});

// Clear chat history endpoint
app.post("/api/chat/clear", authenticateToken, async (req, res) => {
  try {
    const sessionToken = req.headers["authorization"].split(" ")[1];
    const session = sessions.get(sessionToken);
    
    session.chatHistory = [];
    chatHistory[session.user.id] = [];
    await saveChatHistory(chatHistory);

    res.json({
      success: true,
      message: "Chat history cleared successfully",
    });
  } catch (error) {
    res.status(500).json({ success: false, error: "Failed to clear chat history" });
  }
});

// Stock analysis endpoint
app.post("/api/stock-analysis", async (req, res) => {
  try {
    console.log("reached here 1");
    const session_id = "mcp-session-594e48ea-fea1-40ef-8c52-7552dd9272af";
    const mcpResponse = await fetch("http://localhost:8080/mcp/stream", {
      method: "POST",
      headers: {
        "Mcp-Session-Id": session_id,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "tools/call",
        params: {
          name: "fetch_mf_transactions",
          arguments: {},
        },
      }),
    });

    const mcpResult = await mcpResponse.json();
    const textContent = mcpResult?.result?.content?.[0]?.text;
    console.log("MCP Response:", textContent);

    const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
    const GEMINI_API_KEY = "AIzaSyAAy8qvRuJavw6h7Se2weyQSkHFRKu3dow";

    const prompt = `
Given the mutual fund transactions for a user: ${textContent}. 
Suggest up to 5 US stocks (in NASDAQ format, e.g., ["AAPL", "GOOGL"]) that align with the user's risk appetite and industry preferences. 
For each stock, provide the following indicators: PE Ratio, Profit Margin, 50-Day Moving Average, Beta, 52-Week High, 52-Week Low, and a one-sentence reason why this stock might be a good investment opportunity based on these metrics. 
If any metric is unavailable, note it as "N/A" and base the analysis on available data. 
Return the response as a JSON array of objects, each containing the stock symbol, indicators, and reason, in the following format:
[
  {
    "symbol": "AAPL",
    "peRatio": "30.5",
    "profitMargin": "0.25",
    "fiftyDayMovingAverage": "150.75",
    "beta": "1.2",
    "fiftyTwoWeekHigh": "180.0",
    "fiftyTwoWeekLow": "120.0",
    "reason": "AAPL is a strong investment due to its high profit margin and stable beta."
  },
  ...
]
Return only the JSON array as a plain string, without Markdown, code fences, or additional text.
`;

    let reply;
    try {
      const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { text: prompt },
              ],
            },
          ],
        }),
      });

      const data = await response.json();
      reply = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      console.log("Raw Gemini Response:", reply);

    } catch (error) {
      console.error("Error calling Gemini API:", error);
      return res.status(500).json({ success: false, error: "Failed to get stock suggestions from AI" });
    }

    if (!reply || typeof reply !== "string") {
      console.error("Invalid Gemini reply:", reply);
      return res.status(500).json({ success: false, error: "No valid stock suggestions received from AI" });
    }

    let stockData;
    try {
      // Clean the response by removing Markdown code fences and extra whitespace
      const cleanedReply = reply
        .replace(/```json\n?/, '') // Remove opening ```json
        .replace(/\n?```/, '')     // Remove closing ```
        .trim();                   // Remove leading/trailing whitespace

      stockData = JSON.parse(cleanedReply);
      if (!Array.isArray(stockData)) {
        throw new Error("Response is not an array");
      }
      if (stockData.length === 0) {
        throw new Error("Empty stock suggestions array");
      }
    } catch (parseError) {
      console.error("Error parsing Gemini reply:", parseError, "Raw reply:", reply);
      return res.status(500).json({ success: false, error: "Invalid stock suggestions format from AI" });
    }

    res.json({
      success: true,
      data: stockData,
    });
  } catch (error) {
    console.error("Stock analysis error:", error);
    res.status(500).json({ success: false, error: "Failed to analyze stocks" });
  }
});

// Health check
app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    message: "Server is running",
    timestamp: new Date().toISOString(),
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});